const {
  default: makeWASocket,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState
} = require("@whiskeysockets/baileys");
const qrcode = require("qrcode-terminal");

const { findCommand } = require("../commands");
const { env } = require("../config/env");
const { logger } = require("../logger");

const SESSION_DIR = ".session";

async function startWhatsAppBot() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const socket = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger)
    },
    logger,
    printQRInTerminal: false,
    browser: ["BangBot", "Desktop", "1.0.0"]
  });

  socket.ev.on("creds.update", saveCreds);

  socket.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      qrcode.generate(qr, { small: true });
      logger.info("Scan QR di atas untuk login ke WhatsApp.");
    }

    if (connection === "open") {
      logger.info({ botName: env.BOT_NAME }, "Koneksi WhatsApp berhasil.");
    }

    if (connection === "close") {
      const shouldReconnect =
        (((lastDisconnect || {}).error || {}).output || {}).statusCode !== DisconnectReason.loggedOut;

      logger.warn({ shouldReconnect }, "Koneksi WhatsApp terputus.");

      if (shouldReconnect) {
        void startWhatsAppBot();
      }
    }
  });

  socket.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") {
      return;
    }

    for (const message of messages) {
      const remoteJid = message.key.remoteJid;
      const text =
        (message.message && message.message.conversation) ||
        (message.message &&
          message.message.extendedTextMessage &&
          message.message.extendedTextMessage.text) ||
        "";

      if (!remoteJid || !text || message.key.fromMe) {
        continue;
      }

      if (!text.startsWith(env.BOT_PREFIX)) {
        continue;
      }

      const withoutPrefix = text.slice(env.BOT_PREFIX.length).trim();
      const [name, ...args] = withoutPrefix.split(/\s+/);
      const command = findCommand(name || "");

      if (!command) {
        await socket.sendMessage(remoteJid, {
          text: `Command tidak dikenal. Ketik ${env.BOT_PREFIX}help untuk melihat daftar command.`
        });
        continue;
      }

      try {
        await command.execute(args, {
          senderJid: remoteJid,
          pushName: message.pushName || undefined,
          reply: async (replyText) => {
            await socket.sendMessage(remoteJid, { text: replyText });
          }
        });
      } catch (error) {
        logger.error({ err: error, command: command.name }, "Gagal menjalankan command.");
        await socket.sendMessage(remoteJid, {
          text: "Terjadi error saat menjalankan command."
        });
      }
    }
  });
}

module.exports = { startWhatsAppBot };
