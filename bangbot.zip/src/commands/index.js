const { createHelpCommand } = require("./help");
const { pingCommand } = require("./ping");

const baseCommands = [pingCommand];

const commandList = [
  ...baseCommands,
  createHelpCommand(baseCommands)
];

function findCommand(input) {
  const normalized = input.trim().toLowerCase();

  return commandList.find((command) => {
    if (command.name === normalized) {
      return true;
    }

    return command.aliases ? command.aliases.includes(normalized) : false;
  });
}

module.exports = {
  commandList,
  findCommand
};
