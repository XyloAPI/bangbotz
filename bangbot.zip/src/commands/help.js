function createHelpCommand(commands) {
  return {
    name: "help",
    description: "Menampilkan daftar command yang tersedia.",
    aliases: ["menu"],
    async execute(_args, context) {
      const lines = commands.map((command) => `- ${command.name}: ${command.description}`);
      await context.reply(["Daftar command:", ...lines].join("\n"));
    }
  };
}

module.exports = { createHelpCommand };
